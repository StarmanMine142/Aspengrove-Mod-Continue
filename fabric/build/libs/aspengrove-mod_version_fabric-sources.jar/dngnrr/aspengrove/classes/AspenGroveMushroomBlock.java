package dngnrr.aspengrove.classes;

import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.BonemealSource;
import net.minecraft.world.level.block.MushroomBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.AbstractHugeMushroomFeature;
import net.minecraft.world.level.levelgen.feature.Feature;

public class AspenGroveMushroomBlock extends MushroomBlock {
    private final ResourceKey<Feature> feature;

    public AspenGroveMushroomBlock(final ResourceKey<Feature> feature, final BlockBehaviour.Properties properties) {
        super(feature, properties);
        this.feature = feature;
    }

    @Override
    public boolean growMushroom(final ServerLevel level, final BlockPos pos, final BlockState state, final RandomSource random) {
        Optional<? extends Holder<Feature>> featureHolder = level.registryAccess().lookupOrThrow(Registries.FEATURE).get(this.feature);
        if (featureHolder.isEmpty()) {
            return false;
        } else {
            level.removeBlock(pos, false);
            if (((Feature)((Holder)featureHolder.get()).value()).place(level, level.getChunkSource().getGenerator(), random, pos)) {
                return true;
            } else {
                level.setBlockAndUpdate(pos, state);
                return false;
            }
        }
    }

    @Override
    public boolean isValidBonemealTarget(final LevelReader level, final BlockPos pos, final BlockState state, final BonemealSource source) {
        if (level instanceof ServerLevel serverLevel) {
            Optional<? extends Holder<Feature>> featureHolder = serverLevel.registryAccess().lookupOrThrow(Registries.FEATURE).get(this.feature);
            if (featureHolder.isPresent()) {
                Feature feature = (Feature)((Holder)featureHolder.get()).value();
                if (feature instanceof AbstractHugeMushroomFeature mushroomFeature) {
                    int minHeight = 4 + mushroomFeature.foliageRadius();
                    return level.isInsideBuildHeight(pos.above(minHeight));
                } else {
                    return true;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    @Override
    public boolean isBonemealSuccess(final Level level, final RandomSource random, final BlockPos pos, final BlockState state, final BonemealSource source) {
        return (double)random.nextFloat() < 0.4;
    }

    @Override
    public void performBonemeal(final ServerLevel level, final RandomSource random, final BlockPos pos, final BlockState state, final BonemealSource source) {
        this.growMushroom(level, pos, state, random);
    }
}