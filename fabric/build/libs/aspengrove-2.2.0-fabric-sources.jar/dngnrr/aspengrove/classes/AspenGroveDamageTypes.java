package dngnrr.aspengrove.classes;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.level.Level;

public class AspenGroveDamageTypes {
    public static final ResourceKey<DamageType> SPIKED = ResourceKey.create(
            Registries.DAMAGE_TYPE,
            Identifier.fromNamespaceAndPath("aspengrove", "spiked")
    );

    public static DamageSource of(Level level, ResourceKey<DamageType> key) {
        return new DamageSource(
                level.registryAccess().lookupOrThrow(Registries.DAMAGE_TYPE).getOrThrow(key)
        );
    }
}