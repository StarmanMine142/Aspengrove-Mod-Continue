package com.mojang.blaze3d.platform;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface WindowEventHandler {
	void framebufferSizeChanged();

	void resizeGui();

	void cursorEntered();

	void fullscreenStateChanged(boolean fullscreen);
}
