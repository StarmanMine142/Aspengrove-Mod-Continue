package com.mojang.blaze3d;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.TimeUtil;
import org.lwjgl.sdl.SDLTimer;
import org.lwjgl.system.MemoryUtil;

@Environment(EnvType.CLIENT)
public class Blaze3D {
	public static void youJustLostTheGame() {
		MemoryUtil.memSet(0L, 0, 1L);
	}

	public static double getTime() {
		return (double)SDLTimer.SDL_GetTicksNS() / TimeUtil.NANOSECONDS_PER_SECOND;
	}

	private Blaze3D() {
	}
}
