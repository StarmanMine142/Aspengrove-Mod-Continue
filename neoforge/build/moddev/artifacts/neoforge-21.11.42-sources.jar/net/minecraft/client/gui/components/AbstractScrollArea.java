package net.minecraft.client.gui.components;

import com.mojang.blaze3d.platform.cursor.CursorTypes;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class AbstractScrollArea extends AbstractWidget {
    public static final int SCROLLBAR_WIDTH = 6;
    private double scrollAmount;
    private static final Identifier SCROLLER_SPRITE = Identifier.withDefaultNamespace("widget/scroller");
    private static final Identifier SCROLLER_BACKGROUND_SPRITE = Identifier.withDefaultNamespace("widget/scroller_background");
    private boolean scrolling;

    public AbstractScrollArea(int p_386878_, int p_387233_, int p_388234_, int p_386759_, Component p_388945_) {
        super(p_386878_, p_387233_, p_388234_, p_386759_, p_388945_);
    }

    @Override
    public boolean mouseScrolled(double p_388530_, double p_387300_, double p_388604_, double p_386550_) {
        if (!this.visible) {
            return false;
        } else {
            this.setScrollAmount(this.scrollAmount() - p_386550_ * this.scrollRate());
            return true;
        }
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent p_447056_, double p_387876_, double p_387261_) {
        if (this.scrolling) {
            if (p_447056_.y() < this.getY()) {
                this.setScrollAmount(0.0);
            } else if (p_447056_.y() > this.getBottom()) {
                this.setScrollAmount(this.maxScrollAmount());
            } else {
                double d0 = Math.max(1, this.maxScrollAmount());
                int i = this.scrollerHeight();
                double d1 = Math.max(1.0, d0 / (this.height - i));
                this.setScrollAmount(this.scrollAmount() + p_387261_ * d1);
            }

            return true;
        } else {
            return super.mouseDragged(p_447056_, p_387876_, p_387261_);
        }
    }

    @Override
    public void onRelease(MouseButtonEvent p_445716_) {
        this.scrolling = false;
    }

    public double scrollAmount() {
        return this.scrollAmount;
    }

    public void setScrollAmount(double p_387814_) {
        this.scrollAmount = Mth.clamp(p_387814_, 0.0, (double)this.maxScrollAmount());
    }

    public boolean updateScrolling(MouseButtonEvent p_446259_) {
        this.scrolling = this.scrollbarVisible() && this.isValidClickButton(p_446259_.buttonInfo()) && this.isOverScrollbar(p_446259_.x(), p_446259_.y());
        return this.scrolling;
    }

    protected boolean isOverScrollbar(double p_442872_, double p_443339_) {
        return p_442872_ >= this.scrollBarX() && p_442872_ <= this.scrollBarX() + 6 && p_443339_ >= this.getY() && p_443339_ < this.getBottom();
    }

    public void refreshScrollAmount() {
        this.setScrollAmount(this.scrollAmount);
    }

    public int maxScrollAmount() {
        return Math.max(0, this.contentHeight() - this.height);
    }

    protected boolean scrollbarVisible() {
        return this.maxScrollAmount() > 0;
    }

    protected int scrollerHeight() {
        return Mth.clamp((int)((float)(this.height * this.height) / this.contentHeight()), 32, this.height - 8);
    }

    protected int scrollBarX() {
        return this.getRight() - 6;
    }

    protected int scrollBarY() {
        return Math.max(this.getY(), (int)this.scrollAmount * (this.height - this.scrollerHeight()) / this.maxScrollAmount() + this.getY());
    }

    protected void renderScrollbar(GuiGraphics p_386501_, int p_442814_, int p_443619_) {
        if (this.scrollbarVisible()) {
            int i = this.scrollBarX();
            int j = this.scrollerHeight();
            int k = this.scrollBarY();
            p_386501_.blitSprite(RenderPipelines.GUI_TEXTURED, SCROLLER_BACKGROUND_SPRITE, i, this.getY(), 6, this.getHeight());
            p_386501_.blitSprite(RenderPipelines.GUI_TEXTURED, SCROLLER_SPRITE, i, k, 6, j);
            if (this.isOverScrollbar(p_442814_, p_443619_)) {
                p_386501_.requestCursor(this.scrolling ? CursorTypes.RESIZE_NS : CursorTypes.POINTING_HAND);
            }
        }
    }

    protected abstract int contentHeight();

    protected abstract double scrollRate();
}
